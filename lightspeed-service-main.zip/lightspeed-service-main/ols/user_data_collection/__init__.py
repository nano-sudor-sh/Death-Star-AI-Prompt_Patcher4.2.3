"""User data collection package."""
