"""OpenShift Lightspeed service."""

from ols.utils.config import config

__all__ = ["config"]
