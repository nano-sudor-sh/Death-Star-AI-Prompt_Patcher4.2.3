"""Utility classes and functions."""
