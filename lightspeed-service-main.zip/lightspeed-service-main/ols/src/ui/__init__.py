"""Web-based user interface handler."""
