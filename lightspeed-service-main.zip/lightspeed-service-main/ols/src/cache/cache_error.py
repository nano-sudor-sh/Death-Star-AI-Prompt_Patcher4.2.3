"""Any exception that can occur during cache operations."""


class CacheError(Exception):
    """Any exception that can occur during cache operations."""
