"""Constants/methods for prompts."""
