"""Data schemas for payloads send and received via REST API."""
