"""Handlers for all REST API service endpoints."""
