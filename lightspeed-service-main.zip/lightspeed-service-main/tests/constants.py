"""Constants used only in tests."""

# embeddings metadata
OCP_DOCS_ROOT_URL = "https://docs.openshift.com/container-platform"
OCP_DOCS_VERSION = "4.15"
