"""Test cases for rag index related modules."""
