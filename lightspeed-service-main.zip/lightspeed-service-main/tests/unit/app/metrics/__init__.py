"""Init of tests/unit/app/metrics."""
