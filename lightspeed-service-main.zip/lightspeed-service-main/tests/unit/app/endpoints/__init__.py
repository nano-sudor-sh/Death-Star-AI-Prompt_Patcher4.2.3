"""Init of tests/unit/app/endpoints."""
