"""Init of tests/unit/app/models."""
