"""Test cases GradioUI functionality."""
