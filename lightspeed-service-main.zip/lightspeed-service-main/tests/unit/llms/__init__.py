"""Test cases for LLMProvider registry."""
