"""Unit tests for prompt generator."""
