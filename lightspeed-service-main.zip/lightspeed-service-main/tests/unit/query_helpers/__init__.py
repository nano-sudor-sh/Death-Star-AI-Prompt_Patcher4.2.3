"""Test cases for query helpers classes."""
