"""Test cases for utility classes and functions from ols/utils/."""
