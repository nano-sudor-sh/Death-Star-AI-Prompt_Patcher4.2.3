"""Mocks that are used in unit tests."""
