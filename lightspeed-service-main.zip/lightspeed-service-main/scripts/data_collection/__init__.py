"""Data collection utilities."""
